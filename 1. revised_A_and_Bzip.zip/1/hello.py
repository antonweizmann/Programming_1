
print("What is your name?")
user_name = input()
print("Hello " + user_name)
