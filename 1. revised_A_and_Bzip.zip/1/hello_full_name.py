
print("What is your name?")
user_name = input()
print("What is your surname?")
user_surname = input()
print("Hello " + user_name + user_surname)
