num1 = int(input())
num2 = int(input())
if num1 < num2:
    print(str(num2 - num1))
else:
    print(str(num1 - num2))
