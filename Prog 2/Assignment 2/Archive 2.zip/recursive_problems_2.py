import numpy as np


def move_max_rec(arr: np.ndarray[int]) -> np.ndarray[int]:
    current = -1
    nextt = 0
    for nextt in range(len(arr) - 1):
        current += 1
        nextt = current + 1
        if arr[current] > arr[nextt]:
            tmp = arr[nextt]
            arr[nextt] = arr[current]
            arr[current] = tmp
    return arr


def is_substring(big_string: str, sub_string: str) -> bool:
    if len(big_string) < len(sub_string) or not len(big_string) :
        return False
    i = 0
    for i in range(0,len(big_string)):
        if i == len(sub_string):
            return True
        if big_string[i] != sub_string[i]:
            return is_substring(big_string[i + 1:], sub_string)
        i = i + 1
    return False


def find_combinations(input: list, target: int) -> int:
    if target == 0:
        return 1
    elif target < 0 or not len(input):
        return 0
    branch_1 = find_combinations(input[1:], target - input[0])
    branch_2 = find_combinations(input[1:], target)
    return branch_1 + branch_2


def sort_array(arr: np.ndarray[int]) -> np.ndarray[int]:
    if len(arr) == 1:
        return arr
    head = arr[0:1]
    sorted_arr = sort_array(arr[1:])
    i = 0
    while head[0] > sorted_arr[i]:
        i += 1
        if i == sorted_arr.shape[0]:
            break
    new_arr = np.concatenate((sorted_arr[0: i], head, sorted_arr[i:]) )
    return new_arr

















    # sorted_arr = np.asarray([1, 2, 5, 10])
    # new_value = 8
    # i = 0
    # while new_value > sorted_arr[i]:
    #     i += 1
    #     if i == sorted_arr.shape[0]:
    #         break
    #     new_arr = np.concatenate((sorted_arr[0: i], np.asarray ([new_value]), sorted_arr[i:]))
    #
    # print(sorted_arr)
    # print(new_arr)
    # return new_arr
    #
